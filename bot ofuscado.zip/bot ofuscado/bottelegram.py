import json
import requests
import time
import os
from flask import Flask
from menus import mostrar_menu, crear_directorio, ver_json, eliminar_archivo, obtener_link, listar_usuarios, guardar_usuario

# Variables globales para manejar el estado de registro
esperando_id = False
chat_id_usuario = None
chat_id_admin = None
app = Flask(__name__)

# Definir las rutas principales
RUTA_PRINCIPAL1 = '/var/www/botlatamsrc/updatesjsonlatamsrc/'
RUTA_PRINCIPAL = '/var/www/botlatamsrc/updatesjsonlatamsrc/configlatamsrc/'
RUTA_USUARIOS = '/var/www/botlatamsrc/updatesjsonlatamsrc/configlatamsrc/usuariostg.json'


def cargar_configuracion(): 
    with open(os.path.join(RUTA_PRINCIPAL, 'bottelegram.json')) as f:
        return json.load(f)

def cargar_dominio():
    dominio_path = os.path.join(RUTA_PRINCIPAL, 'dominio.json')
    if os.path.exists(dominio_path):
        with open(dominio_path) as f:
            return json.load(f)
    return {}

def get_updates(token, offset=None):
    url = f'https://api.telegram.org/bot{token}/getUpdates'
    params = {'timeout': 100, 'offset': offset}
    response = requests.get(url, params=params)
    return response.json()
    
def recibir_id_usuario(chat_id, token, user_id):
    mensaje = f"Has recibido el ID de usuario: {user_id}"
    requests.post(f'https://api.telegram.org/bot{token}/sendMessage', json={'chat_id': chat_id, 'text': mensaje})

def enviar_mensaje_prueba(chat_id, token):
    mensaje = "Este es un mensaje de prueba."
    requests.post(f'https://api.telegram.org/bot{token}/sendMessage', json={'chat_id': chat_id, 'text': mensaje})

ADMIN_IDS = [1829867818, 987654321]  # Reemplaza con los IDs de los administradores

def procesar_mensaje(mensaje):
    chat_id = mensaje['chat']['id']
    user_id = mensaje['from']['id']  # Obtener el user_id del mensaje

    if 'text' in mensaje:
        text = mensaje['text']
        print(f"Chat ID: {chat_id}, Texto: {text}")

        config = cargar_configuracion()
        token = config['token']

        es_administrador = chat_id in ADMIN_IDS  # Verificar si el usuario es administrador

        if text == '/start':
            mensaje_bienvenida(chat_id, token)
            requests.post(f'https://api.telegram.org/bot{token}/deleteMessage', json={'chat_id': chat_id, 'message_id': mensaje['message_id']})
        elif text == '/menu':
            mostrar_menu(chat_id, token, es_administrador)  # Pasar el estado de administrador
            requests.post(f'https://api.telegram.org/bot{token}/deleteMessage', json={'chat_id': chat_id, 'message_id': mensaje['message_id']})
        elif text.isdigit() and len(text) >= 6 and es_administrador:
            recibir_id_usuario(chat_id, token, text)   
        elif text.startswith('/registrar'):
            partes = text.split()
            if len(partes) == 2 and partes[1].isdigit():
                user_id_a_registrar = int(partes[1])
                guardar_usuario(user_id_a_registrar)
                mensaje_respuesta = f"Usuario con ID {user_id_a_registrar} registrado exitosamente."
                # Enviar mensaje de confirmación al usuario
                requests.post(f'https://api.telegram.org/bot{token}/sendMessage', json={'chat_id': chat_id, 'text': mensaje_respuesta})
                # Eliminar el mensaje de registro
                requests.post(f'https://api.telegram.org/bot{token}/deleteMessage', json={'chat_id': chat_id, 'message_id': mensaje['message_id']})
            else:
                mensaje_error = "Por favor, proporciona un ID válido después del comando /registrar (ejemplo: /registrar 12345678)."
                # Enviar mensaje de error al usuario
                requests.post(f'https://api.telegram.org/bot{token}/sendMessage', json={'chat_id': chat_id, 'text': mensaje_error})
        else:
            if chat_id in nombres_archivos_temp:
                guardar_archivo_con_nombre(chat_id, text)

    elif 'document' in mensaje:
        procesar_archivo_json(mensaje)


nombres_archivos_temp = {}

def mensaje_bienvenida(chat_id, token):
    mensaje = f"HOLA USUARIO, GRACIAS POR USAR NUESTRO BOT. ESTE ES TU ID TELEGRAM: {chat_id}"
    requests.post(f'https://api.telegram.org/bot{token}/sendMessage', json={'chat_id': chat_id, 'text': mensaje})

def procesar_archivo_json(mensaje):
    chat_id = mensaje['chat']['id']
    user_id = mensaje['from']['id']
    file_id = mensaje['document']['file_id']
    
    # Obtener el archivo
    config = cargar_configuracion()
    token = config['token']
    file_path_response = requests.get(f'https://api.telegram.org/bot{token}/getFile', params={'file_id': file_id})

    if file_path_response.status_code != 200:
        print("Error al obtener la ruta del archivo.")
        return

    file_path = file_path_response.json().get('result', {}).get('file_path')
    if not file_path:
        print("No se pudo obtener la ruta del archivo.")
        return

    file_url = f'https://api.telegram.org/file/bot{token}/{file_path}'
    
    # Descargar el archivo
    response = requests.get(file_url)
    if response.status_code != 200:
        print(f"Error al descargar el archivo: {response.status_code}")
        return
    
    # Guardar el archivo temporalmente
    temp_directory_path = os.path.join(RUTA_PRINCIPAL1, 'temp', str(user_id))
    os.makedirs(temp_directory_path, exist_ok=True)
    temp_file_name = f"{user_id}_archivo_temp.json"
    temp_file_full_path = os.path.join(temp_directory_path, temp_file_name)
    
    with open(temp_file_full_path, 'wb') as f:
        f.write(response.content)
    
    # Pedir al usuario que asigne un nombre al archivo
    nombres_archivos_temp[chat_id] = temp_file_full_path
    mensaje = "Archivo JSON recibido. Por favor, envía el nombre que deseas asignar a tu archivo."
    requests.post(f'https://api.telegram.org/bot{token}/sendMessage', json={'chat_id': chat_id, 'text': mensaje})


def guardar_archivo_con_nombre(chat_id, nombre_archivo):
    if chat_id not in nombres_archivos_temp:
        return
    
    temp_file_full_path = nombres_archivos_temp[chat_id]
    user_id = chat_id
    final_directory_path = os.path.join(RUTA_PRINCIPAL1, str(user_id))
    os.makedirs(final_directory_path, exist_ok=True)
    
    if not nombre_archivo.endswith('.json'):
        nombre_archivo += '.json'
    
    final_file_full_path = os.path.join(final_directory_path, nombre_archivo)
    os.rename(temp_file_full_path, final_file_full_path)
    
    mensaje = "Archivo guardado exitosamente con el nombre: " + nombre_archivo
    requests.post(f'https://api.telegram.org/bot{config["token"]}/sendMessage', json={'chat_id': chat_id, 'text': mensaje})
    
    del nombres_archivos_temp[chat_id]

def procesar_callback_query(callback_query):
    callback_data = callback_query['data']
    chat_id = callback_query['message']['chat']['id']
    user_id = callback_query['from']['id']
    config = cargar_configuracion()
    token = config['token']

    if callback_data == "crear_directorio":
        crear_directorio(chat_id, token, user_id)
    elif callback_data == "ver_json":
        ver_json(chat_id, token, user_id)
    elif callback_data == "guardar_nuevo_json":
        requests.post(f'https://api.telegram.org/bot{token}/sendMessage', json={'chat_id': chat_id, 'text': "Por favor, envía el archivo JSON."})
    elif callback_data.startswith("obtener_link_"):
        archivo = callback_data.split("_", 2)[2]
        link = obtener_link(archivo, user_id)
        requests.post(f'https://api.telegram.org/bot{token}/sendMessage', json={'chat_id': chat_id, 'text': f"Tu enlace para descargar el archivo es: {link}"})
    elif callback_data.startswith("eliminar_archivo_"):
        archivo = callback_data.split("_", 2)[2]
        mensaje = eliminar_archivo(user_id, archivo)
        requests.post(f'https://api.telegram.org/bot{token}/sendMessage', json={'chat_id': chat_id, 'text': mensaje})
    elif callback_data == "listar_usuarios":
        listar_usuarios(chat_id, token)
    elif callback_data.startswith("eliminar_usuario_"):
        user_id_a_eliminar = int(callback_data.split("_")[2])
        eliminar_usuario(chat_id, token, user_id_a_eliminar)
def cargar_usuarios():
    if os.path.exists(RUTA_USUARIOS):
        with open(RUTA_USUARIOS) as f:
            return json.load(f)
    return []
def eliminar_usuario(chat_id, token, user_id):
    usuarios = cargar_usuarios()
    if user_id in usuarios:
        usuarios.remove(user_id)
        with open(RUTA_USUARIOS, 'w') as f:
            json.dump(usuarios, f)
        mensaje = f"Usuario con ID {user_id} eliminado exitosamente."
    else:
        mensaje = f"Usuario con ID {user_id} no encontrado."

    requests.post(f'https://api.telegram.org/bot{token}/sendMessage', json={'chat_id': chat_id, 'text': mensaje})









        
if __name__ == '__main__':
    config = cargar_configuracion()
    token = config['token']
    offset = 0

    while True:
        updates = get_updates(token, offset)
        for update in updates.get('result', []):
            if 'message' in update:
                procesar_mensaje(update['message'])
            elif 'callback_query' in update:
                procesar_callback_query(update['callback_query'])
            offset = update['update_id'] + 1
        time.sleep(1)
