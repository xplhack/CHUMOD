# /root/bot/bottelegram.py
import os
import requests
import subprocess
from flask import Flask, request
import time
import json

RUTA_PRINCIPAL1 = '/var/www/botlatamsrc/updatesjsonlatamsrc/'
RUTA_USUARIOS = '/var/www/botlatamsrc/updatesjsonlatamsrc/configlatamsrc/usuariostg.json'
RUTA_PRINCIPAL = '/var/www/botlatamsrc/updatesjsonlatamsrc/configlatamsrc/'

ultimo_menu_id = {}
mensajes_comandos = {}

def cargar_usuarios():
    if os.path.exists(RUTA_USUARIOS):
        with open(RUTA_USUARIOS) as f:
            return json.load(f)
    return []

def guardar_usuario(user_id):
    usuarios = cargar_usuarios()
    if user_id not in usuarios:
        usuarios.append(user_id)
        with open(RUTA_USUARIOS, 'w') as f:
            json.dump(usuarios, f)


def mostrar_menu(chat_id, token, es_administrador=False):
    global ultimo_menu_id
    menu = "Por favor selecciona una opción:\n"
    keyboard = {
        "inline_keyboard": []
    }

    if es_administrador:
        keyboard["inline_keyboard"].append([
             {"text": "Lista de Usuarios", "callback_data": "listar_usuarios"}
        ])


    keyboard["inline_keyboard"].append([
        {"text": "Crear directorio para JSON", "callback_data": "crear_directorio"},
        {"text": "Ver JSON + Link de descarga", "callback_data": "ver_json"},
        {"text": "Guardar nuevo JSON", "callback_data": "guardar_nuevo_json"}
    ])

    # Eliminar los mensajes de comandos anteriores
    if chat_id in mensajes_comandos:
        for msg_id in mensajes_comandos[chat_id]:
            requests.post(f'https://api.telegram.org/bot{token}/deleteMessage', json={'chat_id': chat_id, 'message_id': msg_id})
        mensajes_comandos[chat_id] = []

    response = requests.post(f'https://api.telegram.org/bot{token}/sendMessage', json={'chat_id': chat_id, 'text': menu, 'reply_markup': keyboard})

    ultimo_menu_id[chat_id] = response.json()['result']['message_id']
    if chat_id not in mensajes_comandos:
        mensajes_comandos[chat_id] = []
    mensajes_comandos[chat_id].append(ultimo_menu_id[chat_id])

def crear_directorio(chat_id, token, user_id):
    directory_path = os.path.join(RUTA_PRINCIPAL1, str(user_id))
    try:
        os.makedirs(directory_path, exist_ok=True)
        cambiar_permisos(directory_path)
        mensaje = "Directorio creado exitosamente."
    except Exception as e:
        mensaje = f"Error al crear el directorio: {str(e)}"
    
    requests.post(f'https://api.telegram.org/bot{token}/sendMessage', json={'chat_id': chat_id, 'text': mensaje})

def ver_json(chat_id, token, user_id):
    directory_path = os.path.join(RUTA_PRINCIPAL1, str(user_id))
    try:
        archivos = os.listdir(directory_path)
        if archivos:
            mensaje = "Archivos JSON disponibles:\n"
            keyboard = {
                "inline_keyboard": []
            }
            for archivo in archivos:
                if archivo.endswith('.json'):
                    keyboard["inline_keyboard"].append(
                        [
                            {"text": archivo, "callback_data": f"obtener_link_{archivo}"},
                            {"text": "Eliminar", "callback_data": f"eliminar_archivo_{archivo}"}
                        ]
                    )
            requests.post(f'https://api.telegram.org/bot{token}/sendMessage', json={'chat_id': chat_id, 'text': mensaje, 'reply_markup': keyboard})
        else:
            mensaje = "No hay archivos JSON disponibles en tu directorio."
            requests.post(f'https://api.telegram.org/bot{token}/sendMessage', json={'chat_id': chat_id, 'text': mensaje})
    except Exception as e:
        mensaje = f"Error al leer el directorio: {str(e)}"
        requests.post(f'https://api.telegram.org/bot{token}/sendMessage', json={'chat_id': chat_id, 'text': mensaje})

def eliminar_archivo(user_id, archivo):
    file_path = os.path.join(RUTA_PRINCIPAL1, str(user_id), archivo)
    try:
        os.remove(file_path)
        return f"El archivo {archivo} ha sido eliminado exitosamente."
    except Exception as e:
        return f"Error al eliminar el archivo: {str(e)}"
def cargar_dominio():
    dominio_path = os.path.join(RUTA_PRINCIPAL, 'dominio.json')
    if os.path.exists(dominio_path):
        with open(dominio_path) as f:
            return json.load(f)
    return {}

def obtener_link(archivo, user_id):
    file_path = os.path.join(RUTA_PRINCIPAL1, str(user_id), archivo)
    if not os.path.exists(file_path):
        print(f"Archivo no encontrado: {file_path}")  # Agregar esta línea
        return "El archivo no existe."
    
    try:
        dominio = cargar_dominio().get("subdominio", "yourserver.com")
        link = f"https://{dominio}/updatesjsonlatamsrc/{user_id}/{archivo}"
        print(f"Link generado: {link}")
        return link
    except Exception as e:
        print(f"Error al generar el link: {str(e)}")
        return "Hubo un error al generar el enlace."



def cambiar_permisos(ruta):
    try:
        subprocess.run(['chmod', '777', ruta], check=True)
    except subprocess.CalledProcessError as e:
        print(f"Error al cambiar permisos: {str(e)}")

def listar_usuarios(chat_id, token):
    usuarios = cargar_usuarios()
    if usuarios:
        mensaje = "Usuarios registrados:\n"
        keyboard = {
            "inline_keyboard": []
        }
        for user in usuarios:
            keyboard["inline_keyboard"].append(

                [

             {"text": f"🗑️ Eliminar {user}", "callback_data": f"eliminar_usuario_{user}"}                    
                ]
            )
        requests.post(f'https://api.telegram.org/bot{token}/sendMessage', json={'chat_id': chat_id, 'text': mensaje, 'reply_markup': keyboard})
    else:
        mensaje = "No hay usuarios registrados."
        requests.post(f'https://api.telegram.org/bot{token}/sendMessage', json={'chat_id': chat_id, 'text': mensaje})


 

