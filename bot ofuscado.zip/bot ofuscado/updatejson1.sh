#!/bin/bash

# URL del ZIP a descargar
URL_ZIP="https://github.com/xplhack/CHUMOD/raw/refs/heads/main/echo_por_LatamSRC.zip"

# Función para descargar y descomprimir el ZIP
function descargar_y_descomprimir {
    echo -e "\033[1;34mDescargando el archivo ZIP...\033[0m"
    wget -q "$URL_ZIP" -O "echo_por_LatamSRC.zip"

    if [ -f "echo_por_LatamSRC.zip" ]; then
        echo -e "\033[1;34mDescomprimiendo el archivo ZIP...\033[0m"
        unzip -o "echo_por_LatamSRC.zip"
        echo -e "\033[1;32mArchivo ZIP descomprimido exitosamente.\033[0m"
        
        # Verifica la existencia de los archivos necesarios
        if [ -f "menus.py" ] && [ -f "bottelegram.py" ]; then
            echo -e "\033[1;32mBOT COMPLETADO 100%\033[0m"
        else
            echo -e "\033[1;31mFALTA ZIP BOT\033[0m"
        fi
        
        # Eliminar el archivo ZIP
        rm -f "echo_por_LatamSRC.zip"
        echo -e "\033[1;32mArchivo ZIP eliminado.\033[0m"
    else
        echo -e "\033[1;31mError al descargar el archivo ZIP.\033[0m"
    fi
}

# Si nginx no está instalado, se instala
if ! command -v nginx &> /dev/null; then
    echo "Nginx no está instalado. Procediendo con la instalación..."
    sudo apt update
    sudo apt install -y nginx
    sudo systemctl start nginx
    sudo systemctl enable nginx
else
    echo "Nginx ya está instalado. No se requiere instalación."
fi

# Función para mostrar la IP y el almacenamiento libre
function mostrar_info {
    ip=$(hostname -I | awk '{print $1}')
    espacio_libre=$(df -h / | awk 'NR==2 {print $4}')
    estado_bot=$(cat /var/www/botlatamsrc/updatesjsonlatamsrc/configlatamsrc/iniciado.sh)
    estado_archivos=0 # 0 = incompleto, 1 = completo

    # Verifica la existencia de los archivos necesarios
    if [ -f "menus.py" ] && [ -f "bottelegram.py" ]; then
        estado_archivos=1 # Completo
    fi

    echo -e "\033[1;34m===========================\033[0m"
    echo -e "\033[1;34m=== ECHO POR GATESCCN ? ===\033[0m"
    echo -e "\033[1;34m===========================\033[0m"
    echo -e "\033[1;34m=== Información del VPS ===\033[0m"
    echo -e "IP del VPS: \033[1;32m$ip\033[0m"
    echo -e "Espacio libre: \033[1;32m$espacio_libre\033[0m"
    
    if [ "$estado_bot" -eq 1 ]; then
        echo -e "\033[1;32mEstado del Bot: INICIADO\033[0m"
    else
        echo -e "\033[1;31mEstado del Bot: APAGADO\033[0m"
    fi

    if [ "$estado_archivos" -eq 1 ]; then
        echo -e "\033[1;32mEstado de Archivos del Bot: COMPLETO\033[0m"
    else
        echo -e "\033[1;31mEstado de Archivos del Bot: INCOMPLETO\033[0m"
    fi

    echo
}

# Función para descomprimir archivos ZIP
function descomprimir_zip {
    for file in *.zip; do
        if [ -f "$file" ]; then
            echo -e "\033[1;34mDescomprimiendo $file...\033[0m"
            unzip -o "$file" -d "${file%.zip}"
            echo -e "\033[1;32m$file descomprimido en ${file%.zip}/\033[0m"
        fi
    done
}

# Llama a la función descomprimir_zip
descomprimir_zip

# Función para mostrar el menú principal
function mostrar_menu {
    clear
    mostrar_info
    echo -e "\033[1;34m=== Menú de updatejson1.sh ===\033[0m"
    echo -e "0) \033[1;36mDescargar Repositorios del Bot\033[0m"
    echo -e "1) \033[1;36mIniciar/Parar Modo Screen\033[0m"
    echo -e "2) \033[1;36mVer Directorio\033[0m"
    echo -e "3) \033[1;36mConfigurar Bot Telegram\033[0m"
    echo -e "4) \033[1;36mConfigurar Subdominio\033[0m"
    echo -e "5) \033[1;36mConfigurar Conf Acceso Web (Nginx)\033[0m"
    echo -e "6) \033[1;36mObtener Certificado SSL\033[0m"
    echo -e "7) \033[1;31mSalir\033[0m"
    echo -n -e "\033[1;33mSeleccione una opción: \033[0m"
}

# Crear el archivo de estado de instalación si no existe
if [ ! -f "/var/www/botlatamsrc/updatesjsonlatamsrc/configlatamsrc/instalado.sh" ]; then
    echo "0" > /var/www/botlatamsrc/updatesjsonlatamsrc/configlatamsrc/instalado.sh # 0 significa no instalado
fi

# Comprobar el estado de instalación
estado_instalacion=$(cat /var/www/botlatamsrc/updatesjsonlatamsrc/configlatamsrc/instalado.sh)

# Comprobar si el directorio ya existe
if [ ! -d "/var/www/botlatamsrc/updatesjsonlatamsrc/configlatamsrc/" ]; then
    echo -n -e "\033[1;33m¿Desea crear un directorio de trabajo? (S/N): \033[0m"
    read respuesta
    if [[ "$respuesta" == "S" || "$respuesta" == "s" ]]; then
        mkdir -p /var/www/botlatamsrc/updatesjsonlatamsrc/configlatamsrc/
        echo -e "\033[1;32mDirectorio '/var/www/botlatamsrc/updatesjsonlatamsrc/configlatamsrc/' creado.\033[0m"
    else
        echo -e "\033[1;31mTerminando el script.\033[0m"
        exit 0
    fi
fi

# Iniciar o parar screen
if [ ! -f "/var/www/botlatamsrc/updatesjsonlatamsrc/configlatamsrc/iniciado.sh" ]; then
    echo "0" > /var/www/botlatamsrc/updatesjsonlatamsrc/configlatamsrc/iniciado.sh # 0 significa screen iniciado
fi

# Bucle principal
while true; do
    mostrar_menu
    read opcion
    case $opcion in
        0)  # Opción para descargar repositorios del bot
            descargar_y_descomprimir
            ;;
        1)
            estado=$(cat /var/www/botlatamsrc/updatesjsonlatamsrc/configlatamsrc/iniciado.sh)
            if [ "$estado" -eq 0 ]; then
                echo -e "\033[1;34mIniciando screen...\033[0m"
                screen -dmS mi_screen bash -c "while true; do sleep 1; done"
                echo "1" > /var/www/botlatamsrc/updatesjsonlatamsrc/configlatamsrc/iniciado.sh # Cambia a 1
                echo -e "\033[1;32mScreen iniciado.\033[0m"
            else
                echo -e "\033[1;34mParando screen...\033[0m"
                screen -S mi_screen -X quit
                echo "0" > /var/www/botlatamsrc/updatesjsonlatamsrc/configlatamsrc/iniciado.sh # Cambia a 0
                echo -e "\033[1;32mScreen parado.\033[0m"
            fi
            ;;
        2)
            echo -e "\033[1;32mDirectorio creado: /var/www/botlatamsrc/updatesjsonlatamsrc/configlatamsrc/\033[0m"
            read -p "Presione Enter para continuar..."
            ;;
        3)
            while true; do
                echo -e "\033[1;34m=== Configuración del Bot Telegram ===\033[0m"
                echo -e "1) \033[1;36mIniciar/Parar Bot\033[0m"
                echo -e "2) \033[1;36mConfigurar Token Bot\033[0m"
                echo -e "3) \033[1;36mConfigurar ID Telegram\033[0m"
                echo -e "4) \033[1;36mEnviar Mensaje de Prueba\033[0m"
                echo -e "5) \033[1;36mVolver al menú principal\033[0m"
                echo -n -e "\033[1;33mSeleccione una opción: \033[0m"
                read opcion_bot
                case $opcion_bot in
                    1)
                        echo -e "\033[1;34mDescargando index.html...\033[0m"
                        curl -o /var/www/botlatamsrc/index.html https://raw.githubusercontent.com/xplhack/CHUMOD/refs/heads/main/index.html
                        chmod +777 updatejson1.sh bottelegram.py menus.py

                        if [ ! -f "/var/www/botlatamsrc/updatesjsonlatamsrc/configlatamsrc/initbot.sh" ]; then
                            echo "0" > /var/www/botlatamsrc/updatesjsonlatamsrc/configlatamsrc/initbot.sh # 0 significa bot iniciado
                        fi
                        estado_bot=$(cat /var/www/botlatamsrc/updatesjsonlatamsrc/configlatamsrc/initbot.sh)
                        if [ "$estado_bot" -eq 0 ]; then
                            echo -e "\033[1;34mIniciando bot...\033[0m"
                            screen -dmS telegram_bot python3 bottelegram.py
                            echo "1" > /var/www/botlatamsrc/updatesjsonlatamsrc/configlatamsrc/initbot.sh # Cambia a 1
                            echo -e "\033[1;32mBot iniciado.\033[0m"
                        else
                            echo -e "\033[1;34mParando bot...\033[0m"
                            screen -S telegram_bot -X quit
                            echo "0" > /var/www/botlatamsrc/updatesjsonlatamsrc/configlatamsrc/initbot.sh # Cambia a 0
                            echo -e "\033[1;32mBot parado.\033[0m"
                        fi
                        ;;
                    2)
                        echo -n -e "\033[1;33mIngrese el Token del Bot: \033[0m"
                        read token
                        echo "{\"token\": \"$token\"}" > /var/www/botlatamsrc/updatesjsonlatamsrc/configlatamsrc/bottelegram.json
                        echo -e "\033[1;32mToken guardado.\033[0m"
                        ;;
                    3)
                        echo -n -e "\033[1;33mIngrese el ID Telegram: \033[0m"
                        read id_telegram
                        jq ".id = \"$id_telegram\"" /var/www/botlatamsrc/updatesjsonlatamsrc/configlatamsrc/bottelegram.json > tmp.json && mv tmp.json /var/www/botlatamsrc/updatesjsonlatamsrc/configlatamsrc/bottelegram.json
                        echo -e "\033[1;32mID Telegram guardado.\033[0m"
                        ;;
                    4)
                        if [ "$(cat /var/www/botlatamsrc/updatesjsonlatamsrc/configlatamsrc/initbot.sh)" -eq 1 ]; then
                            id_telegram=$(jq -r '.id' /var/www/botlatamsrc/updatesjsonlatamsrc/configlatamsrc/bottelegram.json)
                            python3 -c "import requests; requests.post('https://api.telegram.org/bot$(jq -r '.token' /var/www/botlatamsrc/updatesjsonlatamsrc/configlatamsrc/bottelegram.json)/sendMessage', json={'chat_id': '$id_telegram', 'text': 'Este es un mensaje de prueba.'})"
                        else
                            echo -e "\033[1;31mEl bot no está iniciado.\033[0m"
                        fi
                        ;;
                    5)
                        break
                        ;;
                    *)
                        echo -e "\033[1;31mOpción no válida.\033[0m"
                        ;;
                esac
            done
            ;;
        4)  # Opción para configurar el subdominio
            echo -n -e "\033[1;33mIngrese el subdominio: \033[0m"
            read subdominio
            echo "{\"subdominio\": \"$subdominio\"}" > /var/www/botlatamsrc/updatesjsonlatamsrc/configlatamsrc/dominio.json
            echo -e "\033[1;32mSubdominio configurado exitosamente.\033[0m"
            ;;
        5)  # Opción para configurar el acceso web en Nginx
            echo -e "\033[1;34mConfigurando el archivo de configuración de Nginx...\033[0m"
            subdominio=$(jq -r '.subdominio' /var/www/botlatamsrc/updatesjsonlatamsrc/configlatamsrc/dominio.json)

            if [ ! -f "/etc/nginx/sites-available/$subdominio.conf" ]; then
                sudo bash -c "cat <<EOF > /etc/nginx/sites-available/$subdominio.conf
server {
    listen 80;
    server_name $subdominio;

    location /updatesjsonlatamsrc {
        alias /var/www/botlatamsrc/updatesjsonlatamsrc;
        autoindex on;  # Permite listar el contenido del directorio
        index index.html index.htm;
    }

    location / {
        root /var/www/html;
        index index.html index.htm;
    }

    error_log /var/log/nginx/$subdominio.error.log;
    access_log /var/log/nginx/$subdominio.access.log;
}
EOF"
                sudo ln -s /etc/nginx/sites-available/$subdominio.conf /etc/nginx/sites-enabled/
                echo -e "\033[1;32mConfiguración añadida. Es necesario recargar Nginx.\033[0m"
                read -p "¿Recargar ahora? (S/N): " recargar
                if [[ "$recargar" == "S" || "$recargar" == "s" ]]; then
                    sudo systemctl reload nginx
                    echo -e "\033[1;32mNginx recargado.\033[0m"
                else
                    echo -e "\033[1;31mNo se ha realizado el reinicio de Nginx.\033[0m"
                fi
            else
                echo -e "\033[1;33mLa configuración ya existe para el subdominio $subdominio.\033[0m"
            fi
            ;;
        6)  # Opción para obtener un certificado SSL
            echo -e "\033[1;34mObteniendo certificado SSL...\033[0m"
            subdominio=$(jq -r '.subdominio' /var/www/botlatamsrc/updatesjsonlatamsrc/configlatamsrc/dominio.json)
            sudo certbot --nginx -d "$subdominio" --non-interactive --agree-tos -m your-email@example.com
            echo -e "\033[1;32mCertificado SSL obtenido y configuración de Nginx actualizada.\033[0m"
            ;;
        7)
            echo -e "\033[1;31mSaliendo...\033[0m"
            exit 0
            ;;
        *)
            echo -e "\033[1;31mOpción no válida.\033[0m"
            ;;
    esac
done
